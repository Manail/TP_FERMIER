# tp-iot


## Prerequired

-   NPM  => <https://nodejs.org/en/>

## Getting started

First, configure your constants under the configuration part in humidity.js and temperature.js

You can let constants as they are except for the ENDPOINT. You must replace the blank value by your API endpoint.

In order to start sensors, run the following commands :
``` bash
npm i
npm run sensors
```